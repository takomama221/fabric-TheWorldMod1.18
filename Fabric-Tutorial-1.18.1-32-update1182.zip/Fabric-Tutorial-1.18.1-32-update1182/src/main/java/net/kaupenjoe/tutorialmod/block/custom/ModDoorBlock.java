package net.kaupenjoe.tutorialmod.block.custom;

import net.minecraft.block.DoorBlock;

public class ModDoorBlock extends DoorBlock {
    public ModDoorBlock(Settings settings) {
        super(settings);
    }
}
