package net.kaupenjoe.tutorialmod.block.custom;

import net.minecraft.block.PressurePlateBlock;

public class ModPressurePlateBlock extends PressurePlateBlock {
    public ModPressurePlateBlock(ActivationRule type, Settings settings) {
        super(type, settings);
    }
}
