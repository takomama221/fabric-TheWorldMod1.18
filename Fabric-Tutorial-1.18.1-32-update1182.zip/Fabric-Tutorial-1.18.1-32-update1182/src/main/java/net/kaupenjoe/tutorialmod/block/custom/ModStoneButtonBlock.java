package net.kaupenjoe.tutorialmod.block.custom;

import net.minecraft.block.StoneButtonBlock;

public class ModStoneButtonBlock extends StoneButtonBlock {
    public ModStoneButtonBlock(Settings settings) {
        super(settings);
    }
}
