package net.kaupenjoe.tutorialmod.block.custom;

import net.minecraft.block.TrapdoorBlock;

public class ModTrapdoorBlock extends TrapdoorBlock {
    public ModTrapdoorBlock(Settings settings) {
        super(settings);
    }
}
