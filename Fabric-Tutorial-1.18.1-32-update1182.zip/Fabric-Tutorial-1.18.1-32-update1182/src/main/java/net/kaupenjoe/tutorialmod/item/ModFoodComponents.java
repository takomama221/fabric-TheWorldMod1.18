package net.kaupenjoe.tutorialmod.item;

import net.minecraft.item.FoodComponent;

public class ModFoodComponents {
    public static final FoodComponent GRAPE = new FoodComponent.Builder().hunger(2).saturationModifier(0.2f).build();
}
